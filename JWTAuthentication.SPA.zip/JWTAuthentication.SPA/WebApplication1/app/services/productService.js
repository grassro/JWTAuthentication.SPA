﻿'use strict';
app.factory('productService', ['$http', 'ngAuthSettings', function ($http, ngAuthSettings) {

    var serviceBase = ngAuthSettings.apiServiceBaseUri;

    var productServiceFactory = {};

    var _getProducts = function () {

        return $http.get(serviceBase + 'Produto/Listar').then(function (results) {
            return results;
        });
    };

    productServiceFactory.getProducts = _getProducts;

    return productServiceFactory;

}]);