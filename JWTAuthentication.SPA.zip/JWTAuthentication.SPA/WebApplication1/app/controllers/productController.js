﻿'use strict';
app.controller('productController', ['$scope', 'productService', function ($scope, productService) {

    $scope.product = [];

    productService.getProducts().then(function (results) {

        $scope.products = results.data;

    }, function (error) {
        //alert(error.data.message);
    });

}]);