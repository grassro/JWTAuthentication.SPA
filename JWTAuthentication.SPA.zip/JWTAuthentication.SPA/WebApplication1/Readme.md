﻿Instruções para utilização do projeto

1. Ter seguido os passos da aplicação da API

2. Rodar a aplicação da API

3. Rodar o site LTM.SPA

4. Utilizar os dados de acesso:
  UserName: User1
  Password: 1234